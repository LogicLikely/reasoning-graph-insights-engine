# GraphMap

GraphMap is a compact React Flow renderer for large argument graphs. It supports
the original LogicLikely graph shape through `GraphMap` and alternate schemas
through the generic `AdaptedGraphMap` API.

## Consumer usage

Import the component API and the packaged stylesheet:

```tsx
import { GraphMap } from '@logiclikely/graphmap'
import '@logiclikely/graphmap/style.css'
```

Existing consumers can continue passing the legacy `Graph` shape to
`GraphMap`. New consumers provide an adapter that returns a `CanonicalGraph`
and pass it to `AdaptedGraphMap`; the adapter keeps the consumer's original node
and edge objects available to selection and presentation callbacks.

React and ReactDOM are peer dependencies. React Flow and Dagre are installed as
GraphMap runtime dependencies.

## Development

```sh
npm ci
npm run verify
npm run storybook:build
npm run func
```

`npm run test:artifact-consumer` builds and packs GraphMap, installs the exact
archive and its runtime dependencies into an isolated temporary harness,
compiles both supported consumer shapes, and server-renders both public
components with React 18 and React 19.

## Packaging

This repository uses a local, manual release workflow. It does not rely on a
hosted producer build or publish GraphMap to a package registry. Run the checks
locally, then create an immutable package artifact:

```sh
npm run verify
npm run storybook:build
npm run func
npm pack
```

The `prepack` hook always rebuilds `dist` first, so the command works from a
clean clone. Do not overwrite an existing versioned archive; bump the package
version before producing a replacement. Copy the reviewed tarball manually into
each authorized consumer. Registry publication remains disabled by
`private: true`.
